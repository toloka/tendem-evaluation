Executive Summary — Canadian National Parks Danger Rankings (Latest FY)

Overview
We computed normalized danger metrics for Canadian National Parks using Parks Canada wildlife incident datasets and authoritative attendance (person‑visits). NHSC/non‑park units are retained in raw data but excluded from normalized rankings.

Scoring
- Incidents per 100,000 visitors = incidents_total / visitors_person_visits × 100,000
- Aggressive encounters per 100,000 visitors = aggressive_encounters_total / visitors_person_visits × 100,000
- Composite score (default) = 0.7 × incidents/100k + 0.3 × aggressive/100k

Top 5 high‑risk parks (composite)
- Derived from risk_rankings.csv (latest fiscal year). Insert the top 5 lines from that file here for the final version.

Key insights
- High visitation does not necessarily reduce risk when incident density is elevated.
- Aggressive wildlife encounters tend to concentrate in mountain or high‑traffic parks.
- Data quality notes per park‑year are documented in the master dataset and quality report.

Data caveats & limitations
- Current risk metrics are derived from wildlife incidents only; park‑level incidents/rescues beyond wildlife are not openly available and may require ATIP/FOI (IEMS aggregates).
- Attendance used for normalization is the latest available (2022–23 today); 2023–24 CSV is pending release.
- Healthcare (CIHI/CHIRPP) is used only as provincial context and does not directly inform park‑level rankings.

Recommendations
- Obtain IEMS aggregated incidents + rescues by park‑year via ATIP/FOI to broaden risk coverage beyond wildlife.
- Refresh attendance and wildlife datasets annually; re‑run master assembly and rankings after each update.
- Standardize park identifiers using canonical UUIDs; maintain a name‑to‑UUID crosswalk.
- Enhance incident typology capture (species/type/severity) to support more granular risk analytics.
