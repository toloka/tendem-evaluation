ATIP/FOI Request Template — Parks Canada IEMS Aggregated Incidents & Rescues

Date: [Insert today’s date]
To: Parks Canada Access to Information and Privacy (ATIP)
Subject: Request for aggregated counts of visitor incidents and rescues by park and fiscal year (2013–14 to latest)

Scope of request
Please provide annual aggregated counts from the Incident and Event Management System (IEMS) as follows:
- Geography: Each National Park (parks-only; exclude National Historic Sites) under Parks Canada administration
- Timeframe: Fiscal years 2013–14 through the most recent complete fiscal year
- Measures:
  • Total visitor safety incidents (annual count)
  • Total rescues (annual count)
- Format: Machine-readable CSV or XLSX
- Fields requested:
  • park_name (official English name)
  • park_id (stable internal identifier, if available)
  • fiscal_year (e.g., 2013–14, 2022–23)
  • incidents_count (annual)
  • rescues_count (annual)
- Definitions: Please include the operational definitions used for “incident” and “rescue,” any notable exclusions, and any changes in classification over time.
- Notes on data quality: Please flag parks/years with incomplete data, system changes (e.g., OTS → IEMS transition), or caveats affecting comparability.

Delivery & contact
- Preferred delivery: Secure link or email attachment
- Contact: [Insert contact name/email]

Intended use
The requested aggregates will be used to compute normalized danger metrics (incidents/rescues per 100,000 visitors) alongside already collected attendance figures, to produce a transparent, data-driven ranking of Canadian National Parks. Results will be documented with full provenance and limitations.

Thank you for your assistance.
