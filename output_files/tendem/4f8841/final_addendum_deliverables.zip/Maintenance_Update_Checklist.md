Maintenance Note & Annual Update Checklist

Update cadence
- Attendance (Parks Canada): Annual (FY). Add new CSV to attendance_by_park_fy.csv and re‑run normalization.
- Wildlife incidents (Parks Canada HWC): Periodic/annual updates. Refresh summary tables and re‑aggregate.
- Healthcare (CIHI/CHIRPP): Annual; contextual reference only.

Checklist (each cycle)
1) Attendance refresh
   - Download latest Parks Canada attendance CSV (FY), update attendance_by_park_fy.csv
   - Update sources log (clean URLs, licence, accessed/updated dates)
   - Update manifest (sizes, SHA1) and integrity report (row counts, coverage)
2) Wildlife refresh
   - Download updated HWC summary tables (incidents by site/type, aggressive encounters, etc.)
   - Re‑run wildlife aggregation to park × FY totals
   - Update manifest and integrity notes
3) Master assembly
   - Merge attendance + wildlife into master_parks_risk.csv (exclude NHSC/non-park from risk calculations)
   - Recompute per-100k metrics
   - Update data dictionary, transform log, quality report
4) Rankings & documentation
   - Recompute risk_rankings.csv (latest FY)
   - Review scoring_methods.md and sensitivity_notes.md; adjust weights if required
   - Rebuild the multi‑sheet Excel workbook (raw/clean/calculations/rankings/sources/docs)
5) QA & packaging
   - Ensure manifests and SHA1 match all files
   - Verify sources and licence references
   - Produce final zip for client handoff

Notes
- When FY 2023–24 attendance CSV becomes available, refresh attendance, master, and rankings; update manifests/integrity accordingly.
