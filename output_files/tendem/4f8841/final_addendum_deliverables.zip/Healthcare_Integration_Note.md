Healthcare Integration Note (CIHI/CHIRPP)

Role in this project
- CIHI Injury & Trauma (Quick Stats) and NACRS ED visits provide provincial‑level context on injuries and emergency visits by cause and fiscal year.
- CHIRPP is a sentinel ED‑based injury surveillance system offering thematic insights (e.g., winter sports, heat/cold) at national/provincial scale.

Usage
- These datasets are used to interpret trends and provide contextual benchmarks.
- They do not directly influence park‑level normalized rankings due to geography and scope limitations (no park‑level mapping).

Documentation
- Source pages, update cadence, and limitations are cited in the healthcare bundles; integrity reports list fiscal‑year alignment and jurisdiction coverage.
